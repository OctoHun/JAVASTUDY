package practice;

@FunctionalInterface
public interface Predicate {
  public boolean apply(double x);
}
