package practice;

public class Sum implements BinaryOperation{

  @Override
  public double apply(double x, double y) {
   return x + y;
  }
  
}
