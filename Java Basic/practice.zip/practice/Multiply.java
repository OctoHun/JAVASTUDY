package practice;

public final class Multiply implements BinaryOperation {
  @Override
  public double apply(double x, double y) {
    return x * y;
  }
}
