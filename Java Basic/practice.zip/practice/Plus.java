package practice;

public final class Plus implements BinaryOperation{
  @Override
  public double apply(double x, double y) {
    return x + y;
  }
}
