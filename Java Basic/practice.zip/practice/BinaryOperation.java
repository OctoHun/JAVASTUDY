package practice;

@FunctionalInterface
public interface BinaryOperation {
  public double apply(double x, double y);
}